
                    CREATE TABLE companies_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT NOT NULL
                    );

                    CREATE TABLE language_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT NOT NULL
                    );

                    CREATE TABLE status_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT NOT NULL
                    );

                    CREATE TABLE pages_type_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT NOT NULL
                    );

                    CREATE TABLE pages_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT NOT NULL
                    );

                    CREATE TABLE accounts_types_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT NOT NULL
                    );

                    CREATE TABLE accounts_types_captions_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT NOT NULL
                    );

                    CREATE TABLE financial_list_captions_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT NOT NULL
                    );

                    CREATE TABLE financial_list_income_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT NOT NULL
                    );

                    CREATE TABLE finiancial_list_assests_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT NOT NULL
                    );

                    CREATE TABLE finiancial_list_liabilities_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT NOT NULL
                    );

                    CREATE TABLE currency_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT NOT NULL
                    );

                    CREATE TABLE account_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT NOT NULL
                    );

                    CREATE TABLE salesman_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE customers_and_suppliers_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE customer_contacts_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE main_stock_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE service_type_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE main_stock_types_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE measurements_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE measurement_units_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE objects_types_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE items_and_services_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE units_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE items_and_services_units_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE items_and_services_unit_barcodes_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE price_category_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE items_and_services_selling_prices_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE items_and_services_customers_prices_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE pos_cashier_settings_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE pos_cashier_allowed_users_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE pos_payment_types_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE pos_campaign_types_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE pos_campaign_header_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE pos_campaign_stores_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE pos_campaign_items_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE pos_cash_shifts_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE pos_cash_shifts_detail_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE pos_cash_header_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE pos_cash_items_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE pos_cash_card_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE pos_cash_cheqs_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE pos_cash_payment_detail_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE rates_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE bank_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE branches_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE credit_cards_types_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE stores_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE permissions_users_access_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE users_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE permissions_role_users_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE permissions_role_access_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );

                    CREATE TABLE permissions_access_list_tbl (
                        id INTEGER PRIMARY KEY,
                        value TEXT
                    );
                    
                    CREATE TABLE attachments_tbl (
                      id INTEGER PRIMARY KEY,
                      value TEXT
                    ); 
                    
                    CREATE TABLE users_records_permissions_tbl (
                      id INTEGER PRIMARY KEY,
                      value TEXT
                    );

                    INSERT INTO companies_tbl VALUES (1, 'ISRA SOFTWARE COMPANY');

                    INSERT INTO status_tbl VALUES 
                    (1, 'Active'),
                    (2, 'DeActive'),
                    (3, 'Deleted');

                    INSERT INTO language_tbl VALUES 
                    (1, 'ar'),
                    (2, 'en');

                    INSERT INTO accounts_types_captions_tbl VALUES
                    (1, '{""account_type_id"":0,""lang_id"":1,""caption"":""حساب محاسبي""}'),
                    (2, '{""account_type_id"":0,""lang_id"":2,""caption"":""ChartOfAccounts""}'),
                    (3, '{""account_type_id"":1,""lang_id"":1,""caption"":""مندوب""}'),
                    (4, '{""account_type_id"":1,""lang_id"":2,""caption"":""SalesMen""}'),
                    (5, '{""account_type_id"":2,""lang_id"":1,""caption"":""زبائن""}'),
                    (6, '{""account_type_id"":2,""lang_id"":2,""caption"":""Customer""}'),
                    (7, '{""account_type_id"":3,""lang_id"":1,""caption"":""مورد""}'),
                    (8, '{""account_type_id"":3,""lang_id"":2,""caption"":""Supplier""}'),
                    (9, '{""account_type_id"":4,""lang_id"":1,""caption"":""مشترك""}'),
                    (10,'{""account_type_id"":4,""lang_id"":2,""caption"":""Subscriber""}'),
                    (11,'{""account_type_id"":5,""lang_id"":1,""caption"":""اخرين""}'),
                    (12,'{""account_type_id"":5,""lang_id"":2,""caption"":""Others""}'),
                    (13,'{""account_type_id"":6,""lang_id"":1,""caption"":""موظف""}'),
                    (14,'{""account_type_id"":6,""lang_id"":2,""caption"":""Employee""}');